double a,b,c,d;

int main()
{
	a = 3.12345678; b = 4.12345678;
	c = a / b;
}