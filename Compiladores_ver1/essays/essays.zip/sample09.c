int a,b,c;

int main()
{
	a = 312345678; b = 412345678;
	c = a * b;
}