#include <stdio.h>

FILE *src, *object;

extern int gettoken(FILE *);
extern void mypas(void);
extern int lookahead;
