int a,b,c;

int main()
{
	a = 2147483648; b = 987654321;
	c = a + b;
}