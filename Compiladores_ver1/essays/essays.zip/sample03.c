float a,b,c;

int main()
{
	a = 3.12345678; b = 4.12345678;
	c = a + b;
}