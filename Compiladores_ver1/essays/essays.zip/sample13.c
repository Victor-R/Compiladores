int a,b,c,d;

int main()
{
	a = 312345678; b = 412345678;
	c = a / b;
	d = a % b;
}