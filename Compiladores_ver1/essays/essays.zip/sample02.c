long int a,b,c;

int main()
{
	a = 9223372036854775808; b = 412345678;
	c = a + b;
}