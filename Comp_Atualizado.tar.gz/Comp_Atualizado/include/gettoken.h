#define MAXID_SIZE 32
extern char lexeme[MAXID_SIZE+1];
extern int gettoken (FILE *);
